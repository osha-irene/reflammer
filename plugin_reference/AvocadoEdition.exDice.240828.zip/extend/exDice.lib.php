<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 데이터 파싱 처리
function get_exDice_data($file_path, $is_proc = false) {
	$data = file_get_contents($file_path);
	
	// 데이터 파싱 처리
	$_d = array();
	$data = explode("\n", $data);
	for($i=0; $i < count($data); $i++) {
		$_temp = explode(" :: ", $data[$i]);
		$key = str_replace("\\n", "", $_temp[0]);
		$val = str_replace("\\n", "", $_temp[1]);
		$num = explode("||", $val);
		if($num[0] == "상수") {
			$val = "상수";
			$num = $num[1];
		} else {
			if(!$is_proc) { 
				$val = str_replace("||", " : ", $val);
				$num = "";
			} else {
				$val = $num[0];
				$num = $num[1];
			}
		}
		$_d[$key]['val'] = $val;
		$_d[$key]['num'] = $num;
	}
	if(count($data) > 0) {
		$_d['dice_str'] = "";
		$_d['dice_str'] .= $_d['X']['val'] == '상수' ? $_d['X']['num'] : ($_d['X']['val'] == "자유입력" ? "?" : $_d['X']['val']);
		$_d['dice_str'] .= " ".$_d['다이스종류']['val']." ";
		$_d['dice_str'] .= $_d['Y']['val'] == '상수' ? $_d['Y']['num'] : ($_d['Y']['val'] == "자유입력" ? "?" : $_d['Y']['val']);

		$_d['dice_mod_str'] = "";
		$_d['dice_mod_str'] .= $_d['수정타입']['val'] ? $_d['수정타입']['val'].($_d['N']['val'] == '상수' ? $_d['N']['num'] : ($_d['N']['val'] == "자유입력" ? "?" : $_d['N']['val'])) : "";

		$_d['dice_result_str'] = "";
		$_d['dice_result_str'] .= $_d['결과타입']['val'] ? $_d['결과타입']['val'].($_d['R']['val'] == '상수' ? $_d['R']['num'] : ($_d['R']['val'] == "자유입력" ? "?" : $_d['R']['val'])) : "";
	} else {
		$_d = "F";
	}

	return $_d;
}

// 데이터 파싱 : 연동 데이터 추출
function get_exDice_count($ch_id, $data) {
	switch($data['val']) {
		case "상수" : 
			$result = $data['num'];
		break;
		case "S" : 
			$status = @get_status_by_name($ch_id, $data['num']);
			$result = $status['now'];
		break;
		case "C" : 
			$excode = @get_status_extra($data['num'], $ch_id);
			$result = $excode['value'];
		break;
	}
	$result = round($result);
	return $result;
}

// 폭발 주사위(dx) 계산 용도
function get_dxRoll($count, $cri, $result, $result_str) {

	$_chk_big = 0;
	$_chk_critical = 0;
	$_chk_array = '';
	$_add_chk_array = '';
	
	for($i=0; $i < $count; $i++) {
		$_seed = rand(1,10);
		if($_seed >= $cri) {
			$_chk_big = 10;
			$_chk_critical++;
		} else {
			$_chk_big = $_seed >= $_chk_big ? $_seed : $_chk_big;
		}

		$_chk_array .= "{$_add_chk_array}{$_seed}";
		$_add_chk_array = ", ";
	}
	$result_str .= ($result_str != "" ? ", " : "")."[{$_chk_big} | {$_chk_array}]";
	$result += $_chk_big;

	$data = array();
	$data['array'] = $result_str;
	$data['result'] = $result;

	if($_chk_critical > 0) {
		$data = get_dxRoll($_chk_critical, $cri, $result, $result_str);
	}
	return $data;
}
?>