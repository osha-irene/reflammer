<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가
if($log_comment['wr_exDice_log']) {
	if($log_comment['wr_exDice_log'] == "F") {
		echo '<div class="exDiceViewer theme-box"><div clas="tit">오류가 발생했습니다.</div></div>';
	} else {
		$exDice = explode("||",$log_comment['wr_exDice_log']);
		$exDieceStr = $exDice[1];
		$exDieceResult = $exDice[2];
		if($exDice[3]) {
			$exDieceStr .= " :: 결과 {$exDice[2]}";
			$exDieceResult = $exDice[3];
		}
	?>
	<div class="exDiceViewer theme-box">
		<div class="tit"><?=$exDice[0]?></div>
		<div class="result ui-btn point" title="<?=$exDieceStr?>"><?=$exDieceResult?></div>
	</div>
<? }
} ?>