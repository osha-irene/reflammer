<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

if($action_exDice != "") {
	$exDiceLog = "";
	if(!isset($write['wr_exDice_log'])) sql_query(" ALTER TABLE `{$write_table}` ADD `wr_exDice_log` text NOT NULL AFTER `wr_log` ");

	// 파일 가져오기
	$action_exDice_path = G5_DATA_PATH."/file/{$board['bo_table']}/dice/{$action_exDice}.dat";
	$exDice_data = get_exDice_data($action_exDice_path, true);
	if($exDice_data == "F") {
		$exDiceLog = "F";
	} else {
		$dice_count = $_exDice_x ? $_exDice_x : get_exDice_count($character['ch_id'], $exDice_data['X']);
		if($dice_count < 0) $dice_count = 0;
		$dice_shape = $_exDice_y ? $_exDice_y : get_exDice_count($character['ch_id'], $exDice_data['Y']);
		if($dice_shape < 0) $dice_shape = 0;
		$dice_mode = $_exDice_n ? $_exDice_n : get_exDice_count($character['ch_id'], $exDice_data['N']);
		if($dice_mode < 0) $dice_mode = 0;
		$dice_result = $_exDice_r ? $_exDice_r : get_exDice_count($character['ch_id'], $exDice_data['R']);
		if($dice_result < 0) $dice_result = 0;

		$_dice_array = "";
		$_dice_result = 0;
		$_dice_result_str = "";

		switch($exDice_data['다이스종류']['val']) {
			case "d" :
				$add_str = "";
				// 일반 다이스
				for($i=0; $i < $dice_count; $i++) {
					$_seed = rand(1,$dice_shape);
					$_dice_array .= "{$add_str}[{$_seed}]";
					$_dice_result += $_seed;
					$add_str = "+";
				}
			break;
			case "dx" :
				// Dx 다이스 크리티컬 수치 조정
				$dice_shape = $dice_shape < 2 ? 2 : ($dice_shape > 10 ? 10 : $dice_shape);
				$_temp_result = get_dxRoll($dice_count, $dice_shape, 0, "");
				$_dice_result = $_temp_result['result'];
				$_dice_array = $_temp_result['array'];
			break;
		}

		switch($exDice_data['수정타입']['val']) {
			case "＋" :
				$_dice_result += $dice_mode;
				$_dice_array .= "+{$dice_mode}";
			break;
			case "－" : 
				$_dice_result -= $dice_mode;
				$_dice_array .= "-{$dice_mode}";
			break;
		}
		switch($exDice_data['결과타입']['val']) {
			case "＝" :
				$_dice_array .= "＝ {$dice_result}";
				$_dice_result_str = $_dice_result == $dice_result ? "성공" : "실패";
			break;
			case "＞" : 
				$_dice_array .= "＞ {$dice_result}";
				$_dice_result_str = $_dice_result > $dice_result ? "성공" : "실패";
			break;
			case "≥" : 
				$_dice_array .= "≥ {$dice_result}";
				$_dice_result_str = $_dice_result >= $dice_result ? "성공" : "실패";
			break;
			case "＜" : 
				$_dice_array .= "＜ {$dice_result}";
				$_dice_result_str = $_dice_result < $dice_result ? "성공" : "실패";
			break;
			case "≤" : 
				$_dice_array .= "≤ {$dice_result}";
				$_dice_result_str = $_dice_result <= $dice_result ? "성공" : "실패";
			break;
		}

		$exDiceLog = "{$exDice_data['다이스이름']['val']}||{$_dice_array}||{$_dice_result}||{$_dice_result_str}";
	}

	$customer_sql .= " , wr_exDice_log = '{$exDiceLog}'";
}
?>