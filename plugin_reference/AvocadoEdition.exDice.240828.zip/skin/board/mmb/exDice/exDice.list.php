<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

$exDiceList = array();
$board_dice_path = G5_DATA_PATH.'/file/'.$board['bo_table']."/dice";
$tmp = dir($board_dice_path);
$_indexing = 0;
while ($entry = $tmp->read()) {
	if (preg_match("/(\.dat)$/i", $entry)) {
		$temp_path = $board_dice_path."/".$entry;
		$teme_data = get_exDice_data($temp_path, true);
		if(trim($teme_data['사용여부']['val']) != '') {
			$temp_path = explode("/",$temp_path);
			$temp_path = end($temp_path);
			$temp_path = explode(".",$temp_path);
			$temp_path = $temp_path[0];
			$exDiceList[$_indexing]['path'] = $temp_path;
			$exDiceList[$_indexing]['data'] = $teme_data;
			$_indexing++;
		}
	}
}
?>
<style>
.exDiceForm {display:flex; flex-wrap:wrap; align-items:center;}
.exDiceForm > * {display:block; position:relative; flex-grow:1; width:auto !important;}
.exDiceForm .free-dice-form {display:flex; flex-wrap:nowrap; align-items:center; justify-content:center;}
.exDiceForm .free-dice-form > * {display:block; position:relative;}
.exDiceForm .free-dice-form input[type="text"] {width:50px; height:23px; border:1px solid rgba(0,0,0,.3) !important; border-radius:9em !important; background:rgba(255,255,255,.3) !important; padding:0; text-align:center;}

.exDiceViewer {display:flex; flex-wrap:nowrap; align-items:center; justify-content:space-between; margin-bottom:18px; position:relative;}
.exDiceViewer .ui-btn {line-height:26px; cursor:default;}
</style>
<script>
$(function() {
	$('.exDiceForm *[name="action_exDice"]').on('change', function() {
		$(this).next().remove();
		let $data_obj = $(this).find("option:selected");

		if($data_obj.attr('data-free-dice')) {
			let _dice = $data_obj.attr('dice-type-str');
			let _mod = $data_obj.attr('dice-mod-str');
			let _result = $data_obj.attr('dice-result-str');

			let _x = $data_obj.attr('dice-x-str');
			let _y = $data_obj.attr('dice-y-str');
			let _n = $data_obj.attr('dice-n-str');
			let _r = $data_obj.attr('dice-r-str');

			let _html	=	(_x == "INPUT" ? "<input type='text' name='_exDice_x' value='' />" : "<span>" + _x + "</span>")
						+	"<span>" + _dice + "</span>"
						+	(_y == "INPUT" ? "<input type='text' name='_exDice_y' value='' />" : "<span>" + _y + "</span>");
			if(_mod)  _html += "<span>" + _mod + "</span>" + (_n == "INPUT" ? "<input type='text' name='_exDice_n' value='' />" : "<span>" + _n + "</span>");
			if(_result)  _html += "<span>" + _result + "</span>" + (_r == "INPUT" ? "<input type='text' name='_exDice_r' value='' />" : "<span>" + _r + "</span>");

			_html = "<div class='free-dice-form form-input'>" + _html + "</div>";
			$(this).after(_html);
		}
	});
});
</script>