<?php
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가

if(count($exDiceList) > 0) {
	echo "<div class='exDiceForm'><select name='action_exDice'><option value=''>Dice 선택</option>";
	for($k=0; $k < count($exDiceList); $k++) {
		$_d = $exDiceList[$k];
		$_x_str = $_d['data']['X']['val'] == '자유입력' ? "INPUT" : $_d['data']['X']['num'];
		$_y_str = $_d['data']['Y']['val'] == '자유입력' ? "INPUT" : $_d['data']['Y']['num'];
		$_n_str = $_d['data']['N']['val'] == '자유입력' ? "INPUT" : $_d['data']['N']['num'];
		$_r_str = $_d['data']['R']['val'] == '자유입력' ? "INPUT" : $_d['data']['R']['num'];
		
		echo "<option value='{$_d['path']}' data-free-dice='{$_d['data']['자유다이스포함']['val']}' dice-type-str='{$_d['data']['다이스종류']['val']}' dice-mod-str='{$_d['data']['수정타입']['val']}' dice-result-str='{$_d['data']['결과타입']['val']}' dice-x-str='{$_x_str}' dice-y-str='{$_y_str}' dice-n-str='{$_n_str}' dice-r-str='{$_r_str}'>
				{$_d['data']['다이스이름']['val']}
			</option>";
	}
	echo "</select></div>";
}
?>