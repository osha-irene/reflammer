<?php
$sub_menu = "300800";
include_once('./_common.php');

auth_check($auth[$sub_menu], 'w');
check_token();

$board_path = G5_DATA_PATH.'/file/'.$bo_table."/dice";
$prev_board_path = G5_DATA_PATH.'/file/'.$prev_bo_table."/dice";

@mkdir($board_path, G5_DIR_PERMISSION);
@chmod($board_path, G5_DIR_PERMISSION);

if($_POST['act_button'] != "삭제") {

	/*********************************
	다이스 데이터 양식
	----------------------------------
	1.다이스이름 : 임시다이스
	2.사용여부 : Y
	3.다이스종류 : d
	3-1.X : 자유입력
	3-2.Y : 숫자||2
	3-3.N : 스탯||HP
	3-4.R : 연동코드||공격력
	4.수정타입 : ＋
	5.결과타입 : ＞
	6.자유다이스포함 : N
	*********************************/

	// File Name
	$_indexing = $dx_id ? $dx_id : time();

	// 다이스 명 오류 정의
	$dx_name = str_replace(" :: ", ":", $dx_name);

	//기본값 설정
	$dx_x_v = $dx_x_v ? $dx_x_v : 0;
	$dx_y_v = $dx_y_v ? $dx_y_v : 0;
	$dx_n_v = $dx_n_v ? $dx_n_v : 0;
	$dx_r_v = $dx_r_v ? $dx_r_v : 0;

	// 수정 및 결과 정의가 안되어 있을 시 다이스 값 초기화
	$dx_n = $dx_mod ? $dx_n : "";
	$dx_r = $dx_result ? $dx_r : "";

	//수치값 재정의
	$dx_x_result = str_replace(" : ", "||", ($dx_x == "상수" ? $dx_x." : ".$dx_x_v : $dx_x));
	$dx_y_result = str_replace(" : ", "||", ($dx_y == "상수" ? $dx_y." : ".$dx_y_v : $dx_y));
	$dx_n_result = str_replace(" : ", "||", ($dx_n == "상수" ? $dx_n." : ".$dx_n_v : $dx_n));
	$dx_r_result = str_replace(" : ", "||", ($dx_r == "상수" ? $dx_r." : ".$dx_r_v : $dx_r));

	// 자유 다이스 여부
	$free_dice_roll = ($dx_x == "자유입력" || $dx_y == "자유입력" || $dx_n == "자유입력" || $dx_r == "자유입력") ? "Y" : "N";

	if($prev_bo_table) {
		$prev_file_path = "{$prev_board_path}/{$_indexing}.dat";
		unlink($prev_file_path);
	}

	//데이터 파일 기본 셋팅
	$file_path = "{$board_path}/{$_indexing}.dat";
	$f = @fopen($file_path, 'a');
	ob_start();

/**********************************************************************
	[S] Data Template Contents
***********************************************************************/ ?>
다이스이름 :: <?=$dx_name?>

X :: <?=$dx_x_result?>

다이스종류 :: <?=$dx_dice?>

Y :: <?=$dx_y_result?>

수정타입 :: <?=$dx_mod?>

N :: <?=$dx_n_result?>

결과타입 :: <?=$dx_result?>

R :: <?=$dx_r_result?>

사용여부 :: <?=$dx_use?>

자유다이스포함 :: <?=$free_dice_roll?>
<? /*******************************************************************
		[E] Data Template Contents
***********************************************************************/

	$dice_data = ob_get_contents();
	ob_end_flush();
	fwrite($f,$dice_data);
	fclose($f);
	@chmod($file_path, G5_FILE_PERMISSION);
} else {
	$prev_file_path = "{$prev_board_path}/{$dx_id}.dat";
	unlink($prev_file_path);
}
goto_url('./exDice_list.php?'.$qstr);
?>
