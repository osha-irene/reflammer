<?php
$sub_menu = "300800";
include_once('./_common.php');

auth_check($auth[$sub_menu], 'r');
$token = get_token();

// 게시판 목록 들고오기
$sql_common = " from {$g5['board_table']} ";
$sql_search = " where (1) ";
if ($stx) $sql_search .= " and {$sfl} like '%{$stx}%') ";
$sql_order = " order by bo_table asc ";
$sql = " select * {$sql_common} {$sql_search} {$sql_order}";
$result = sql_query($sql);

// 게시판 별 다이스 정보 들고오기
$bo_table_str = array();
$bo_table_value = array();
$dice_list = array();
$dice_list_files = array();
for($i=0; $row = sql_fetch_array($result); $i++) {
	$dice_list_files = null;
	$board_dice_path = G5_DATA_PATH.'/file/'.$row['bo_table']."/dice";
	// 게시판 디렉토리 생성
	@mkdir($board_dice_path, G5_DIR_PERMISSION);
	@chmod($board_dice_path, G5_DIR_PERMISSION);
	$file = $board_path . '/index.php';
	$f = @fopen($file, 'w');
	@fwrite($f, '');
	@fclose($f);
	@chmod($file, G5_FILE_PERMISSION);

	$bo_table_str[] = $row['bo_subject'];
	$bo_table_value[] = $row['bo_table'];
	$tmp = dir($board_dice_path);
	while ($entry = $tmp->read()) {
		if (preg_match("/(\.dat)$/i", $entry)) $dice_list_files[] = $entry;
	}
	
	if(!empty($dice_list_files) && is_array($dice_list_files)) {
		natsort($dice_list_files);
		foreach($dice_list_files as $file) {
			//$str = file_get_contents($board_dice_path."/".$file);
			$str = $board_dice_path."/".$file;
			$_temp_data['data'] = $str;
			$_temp_data['file'] = str_replace(".dat", "", $file);
			$_temp_data['bo_table'] = $row['bo_table'];
			$_temp_data['bo_subject'] = $row['bo_subject'];
			$dice_list[] = $_temp_data;
		}
	}
}

// 옵션(변수값) 목록 설정
// 기본 : 상수, 스탯, 연동코드
$_vals = array("자유입력","상수");
// -- 스탯
$st_result = sql_query("select * from {$g5['status_config_table']} order by st_order asc");
for($i = 0; $row = sql_fetch_array($st_result); $i++) {
	$_vals[] = "S : {$row['st_name']}";
}
// -- 연동코드
if(isset($g5['status_extra_table'])) {
	// 연동코드 기능을 사용할 시
	$extra_result = sql_query("select * from {$g5['status_extra_table']}");
	for($i=0; $ex = sql_fetch_array($extra_result); $i++) {
		$_vals[] = "C : {$ex['ex_name']}";
	}
}

function get_multi_diceForm($name, $values, $prev = "", $prev_num = "") {
	$result = "";
	$result .= "<div class='multi-select'><select name='{$name}'>";
	for($i=0; $i < count($values); $i++) { 
		$result .= "<option value='{$values[$i]}' ".($prev == $values[$i] ? "selected" : "").">{$values[$i]}</option>";
	}
	$result .= "</select><div class='num'><input type='text' name='{$name}_v' value='{$prev_num}' placeholder='0' /></div></div>";
	return $result;
}

$g5['title'] = '다이스 관리';
include_once ('./admin.head.php');
$colspan = 7;
$pg_anchor = '<ul class="anchor">
	<li><a href="#anc_001">다이스 등록</a></li>
	<li><a href="#anc_002">다이스 목록</a></li>
</ul>';
?>

<style>
.dice-set-form input,
.dice-set-form select {font-size:13px !important; padding:0 !important; border:none !important; height:25px !important; width:100% !important; text-align:center; position:relative; z-index:0;}
.dice-set-form select {cursor:pointer;}
.dice-set-form {display:flex; position:relative; flex-wrap:nowrap; align-items:center; gap:5px;}
.dice-set-form > * {display:block; position:relative;}
.dice-set-form .multi-select {border-bottom:1px solid #ddd;}
.dice-set-form .multi-select .num {display:none; position:absolute; top:0; left:0; right:20px; bottom:0; background:#fff; z-index:1;}
.dice-set-form .multi-select.input-text .num {display:block;}
.dice-set-form .sel {border-radius:9em; background:#ffa8a8; padding:0 5px;}
.dice-set-form .sel select {width:2.5em !important; color:#fff; background:transparent !important; -webkit-appearance:none; -moz-appearance:none; -o-appearance:none; appearance:none;}
.dice-set-form .sel select::-ms-expand {display:none;}
.dice-set-form .sel select option {background:#fff; color:#000;}

.dice-set-form .sel.off {background:#eaeaea;}
.dice-set-form .sel.off select {color:#000;}

.tbl_frmGroup {border-top:2px solid #000;}
.tbl_frmGroup .tbl_frm01 {margin:0 !important;}
.tbl_frmGroup .tbl_frm01 > table > tbody {border-top-width:0;}

.control input[type="submit"] {display:inline-block; position:relative; vertical-align:middle; height:30px; padding:0 20px; border-radius:9em; font-size:1em; border:2px solid #81c9c9; background:#fff; color:#41b1b1; cursor:pointer; font-weight:600;}}
</style>
<script>
$(function(){
	$('.multi-select select').each(function() {
		$(this).on('change', function() {
			if($(this).val() == "상수") $(this).closest('.multi-select').addClass('input-text');
			else $(this).closest('.multi-select').removeClass('input-text');
		});
		if($(this).val() == "상수") $(this).closest('.multi-select').addClass('input-text');
		else $(this).closest('.multi-select').removeClass('input-text');
	});

	$('.dice-set-form .sel select').each(function() {
		$(this).on('change', function() {
			if($(this).val() == "") $(this).closest('.sel').addClass('off').next().hide();
			else $(this).closest('.sel').removeClass('off').next().show();
		});
		if($(this).val() == "") $(this).closest('.sel').addClass('off').next().hide();
		else $(this).closest('.sel').removeClass('off').next().show();
	});
});

</script>

<section id="anc_001">
	<h2 class="h2_frm">다이스 등록</h2>
	<?php echo $pg_anchor ?>
	<form name="fsideform" method="post" id="fsideform" action="./exDice_update.php" autocomplete="off">
	<input type="hidden" name="sfl" value="<?php echo $sfl ?>">
	<input type="hidden" name="stx" value="<?php echo $stx ?>">
	<input type="hidden" name="sst" value="<?php echo $sst ?>">
	<input type="hidden" name="sod" value="<?php echo $sod ?>">
	<input type="hidden" name="token" value="<?php echo $token ?>">

	<div class="tbl_frm01 tbl_wrap">
		<table>
		<colgroup>
			<col style="width:100px;">
			<col style="width:120px;">
			<col style="width:130px;">
			<col>
			<col style="width:120px;">
		</colgroup>
		<tbody>
		<tr>
			<th scope="row">
				<input type="checkbox" name="dx_use" value="Y" id="dx_use" checked />
				<label for="dx_use">사용</label>
			</th>
			<td>
				<select name="bo_table" style="width:100%;" required>
					<? for($i=0; $i < count($bo_table_value); $i++) { 
						echo "<option value='{$bo_table_value[$i]}'>{$bo_table_str[$i]}</option>";
					}?>
				</select>
			</td>
			<td><input type="text" name="dx_name" class="required frm_input" style="width:100%;" required placeholder="다이스명"></td>
			<td>
				<div class="dice-set-form">
					<?=get_multi_diceForm("dx_x", $_vals)?>
					<div class="sel">
						<select name="dx_dice">
							<option value="d">d</option>
							<option value="dx">dx</option>
						</select>
					</div>
					<?=get_multi_diceForm("dx_y", $_vals)?>
					<div class="sel">
						<select name="dx_mod">
							<option value=""></option>
							<option value="＋">＋</option>
							<option value="－">－</option>
						</select>
					</div>
					<?=get_multi_diceForm("dx_n", $_vals)?>
					<div class="sel">
						<select name="dx_result">
							<option value=""></option>
							<option value="＝">＝</option>
							<option value="＞">＞</option>
							<option value="≥">≥</option>
							<option value="＜">＜</option>
							<option value="≤">≤</option>
						</select>
					</div>
					<?=get_multi_diceForm("dx_r", $_vals)?>
				</div>
			</td>
			<td>
				<div class="control">
					<input type="submit" name="act_button" value="확인" class="btn_submit">
				</div>
			</td>
		</tr>
		</tbody>
		</table>
	</div>

	<?php echo help("◆ d는 일반 다이스로, 2D6의 경우 6면체 주사위 2개를 굴리는 것을 의미합니다.") ?>
	<?php echo help("◆ dx는 특수 다이스로 기본 10면체를 고정으로 합니다. 2dx10의 경우 10면체 주사위를 2개 굴린 뒤 크리티컬 수치 10이 되는 다이스들은 다시 한번 굴립니다. 더이상 크리티컬 수치가 나오지 않을 때 까지 이를 반복합니다.") ?>
	<?php echo help("◆ ＝, ＞ 등의 비교값을 설정할 경우 결과값에 대한 성공/실패를 출력하게 됩니다.") ?>
	<?php echo help("◆ 자유입력으로 설정할 경우, 다이스를 굴릴 시 숫자를 별도로 입력받게 됩니다.") ?>
	</form>

</section>

<section id="anc_002">
	<h2 class="h2_frm">다이스 목록</h2>
	<?php echo $pg_anchor ?>

	<div class="local_ov01 local_ov">
		<?php echo $listall ?>
		전체 <?php echo number_format(count($dice_list)) ?> 건
	</div>
	
	<form name="fsearch" id="fsearch" class="local_sch01 local_sch" method="get">
		<label for="sfl" class="sound_only">검색대상</label>
		<select name="sfl" id="sfl">
			<option value="bo_table"<?php echo get_selected($_GET['sfl'], "bo_table", true); ?>>TABLE</option>
			<option value="bo_subject"<?php echo get_selected($_GET['sfl'], "bo_subject"); ?>>게시판명</option>
		</select>
		<label for="stx" class="sound_only">검색어<strong class="sound_only"> 필수</strong></label>
		<input type="text" name="stx" value="<?php echo $stx ?>" id="stx" class="frm_input">
		<input type="submit" value="검색" class="btn_submit">
	</form>

	<div class="tbl_frmGroup">

	<?php for ($k=0; $k < count($dice_list); $k++) {
		$d = $dice_list[$k];
		$data = get_exDice_data($d['data']);

		$dice_str = $data['dice_str'];
		$dice_mod_str = $data['dice_mod_str'];
		$dice_result_str = $data['dice_result_str'];
	?>
		<form name="fDiceform<?=$k?>" method="post" action="./exDice_update.php" autocomplete="off"  onsubmit="return fdice_submit(this);">
			<input type="hidden" name="sfl" value="<?php echo $sfl ?>">
			<input type="hidden" name="stx" value="<?php echo $stx ?>">
			<input type="hidden" name="sst" value="<?php echo $sst ?>">
			<input type="hidden" name="sod" value="<?php echo $sod ?>">
			<input type="hidden" name="token" value="<?php echo $token ?>">
			<input type="hidden" name="prev_bo_table" value="<?php echo $d['bo_table'] ?>">
			<input type="hidden" name="dx_id" value="<?php echo $d['file'] ?>">
			<input type="hidden" name="token" value="<?php echo $token ?>">

			<div class="tbl_frm01 tbl_wrap">
				<table>
				<colgroup>
					<col style="width:100px;">
					<col style="width:120px;">
					<col style="width:130px;">
					<col style="width:150px;">
					<col>
					<col style="width:160px;">
				</colgroup>
				<tbody>
				<tr>
					<th scope="row">
						<input type="checkbox" name="dx_use" value="Y" id="dx_use_<?=$k?>" <?=trim($data['사용여부']['val']) !='' ? "checked" : ""?> />
						<label for="dx_use_<?=$k?>">사용</label>
					</th>
					<td>
						<select name="bo_table" style="width:100%;" required>
							<? for($i=0; $i < count($bo_table_value); $i++) { 
								echo "<option value='{$bo_table_value[$i]}' ".($d['bo_table'] == $bo_table_value[$i] ? "selected" : "").">{$bo_table_str[$i]}</option>";
							}?>
						</select>
					</td>
					<td><input type="text" name="dx_name" class="required frm_input" style="width:100%;" required placeholder="다이스명" value="<?=$data['다이스이름']['val']?>"></td>
					<td style="text-align:center; font-weight:600;">
						<span style="color:#333;"><?=$dice_str?></span>
						<span style="color:#ffa8a8;"><?=$dice_mod_str?></span>
						<span style="color:#81c9c9;"><?=$dice_result_str?></span>
					</td>
					<td>
						<div class="dice-set-form">
							<?=get_multi_diceForm("dx_x", $_vals, $data['X']['val'], $data['X']['num'])?>
							<div class="sel">
								<select name="dx_dice">
									<option value="d" <?=$data['다이스종류']['val'] == 'd' ? "selected" : ""?>>d</option>
									<option value="dx" <?=$data['다이스종류']['val'] == 'dx' ? "selected" : ""?>>dx</option>
								</select>
							</div>
							<?=get_multi_diceForm("dx_y", $_vals, $data['Y']['val'], $data['Y']['num'])?>
							<div class="sel">
								<select name="dx_mod">
									<option value=""></option>
									<option value="＋" <?=$data['수정타입']['val'] == '＋' ? "selected" : ""?>>＋</option>
									<option value="－" <?=$data['수정타입']['val'] == '－' ? "selected" : ""?>>－</option>
								</select>
							</div>
							<?=get_multi_diceForm("dx_n", $_vals, $data['N']['val'], $data['N']['num'])?>
							<div class="sel">
								<select name="dx_result">
									<option value=""></option>
									<option value="＝" <?=$data['결과타입']['val'] == '＝' ? "selected" : ""?>>＝</option>
									<option value="＞" <?=$data['결과타입']['val'] == '＞' ? "selected" : ""?>>＞</option>
									<option value="≥" <?=$data['결과타입']['val'] == '≥' ? "selected" : ""?>>≥</option>
									<option value="＜" <?=$data['결과타입']['val'] == '＜' ? "selected" : ""?>>＜</option>
									<option value="≤" <?=$data['결과타입']['val'] == '≤' ? "selected" : ""?>>≤</option>
								</select>
							</div>
							<?=get_multi_diceForm("dx_r", $_vals, $data['R']['val'], $data['R']['num'])?>
						</div>
					</td>
					<td>
						<div class="control">
							<input type="submit" name="act_button" value="확인" class="btn_submit">
							<input type="submit" name="act_button" value="삭제" class="btn_submit" style="border-color:#ffa8a8 !important; background:#ffa8a8 !important;" onclick="document.pressed=this.value" />
						</div>
					</td>
				</tr>
				</tbody>
				</table>
			</div>
		</form>
	<? } ?>

	</div>

</section>


<script>
function fdice_submit(f) {
	if(document.pressed == "삭제") {
		if(!confirm("선택한 자료를 정말 삭제하시겠습니까?")) {
			return false;
		}
	}
	return true;
}
</script>

<?php
include_once ('./admin.tail.php');
?>
