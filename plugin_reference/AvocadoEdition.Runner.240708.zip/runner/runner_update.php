<?php
include_once('./_common.php');

$now = date('Y-m-d H:i:s');
$ru = sql_fetch("select * from {$g5['runner_table']} where ru_id = '{$ru_id}'");

// 정보 유효성 확인
if(!$ru['ru_id']) { alert("경기 정보가 없습니다."); }

// 판돈 거는 기간 확인
if($ru['ru_edatetime'] <= $now) { alert("해당 경기는 종료되었습니다."); }

// 판돈 걸었는지 아닌지 확인
$my = sql_fetch("select rl_id from {$g5['runner_log_table']} where ru_id = '{$ru['ru_id']}' and ch_id = '{$character['ch_id']}'");
if($my['rl_id']) { alert("이미 판돈을 거셨습니다."); }

// 보유 금액 확인
if($member['mb_point'] < $ru_value) alert("보유금액을 초과하였습니다.");

// 로그 입력
$sql = " insert into {$g5['runner_log_table']} set 
	ru_id = '{$ru_id}',
	ri_id = '{$ri_id}',
	ri_name = '{$ri_name}',
	ch_id = '{$character['ch_id']}',
	mb_id = '{$member['mb_id']}',
	ch_name = '{$character['ch_name']}',
	ru_value = '{$ru_value}',
	ru_datetime = '{$now}'
";
sql_query($sql);

// 배팅 금액 인출
insert_point($member['mb_id'], ($ru_value * -1), "{$ru['ru_title']} 경기 : {$ri_name} 배팅 ({$ru_value})", 'game', time(), '배팅');

goto_url('./index.php', false);

?>
