<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가 

?>
<div class="thumb">
	<div class="bak"><img src="<?=$item['ri_img']?>" onerror="this.remove();" /></div>
	<span class="winner-per">승률 <?=$item['win']?></span>
</div>
<div class="name"><?=$item['ri_name']?></div>
<div class="control">
	<? if($my['rl_id']) { ?>
		<div class="result">
			<p>판돈참가 완료 : <em class="txt-point"><?=$my['ri_name']?></em> <?=$my['ru_value']?><?=$config['cf_money_pice']?></p>
		</div>
	<? } else if($ru['ru_edatetime'] <= $now) { ?>
		<div class="result">
			<p>게임이 종료되었습니다.</p>
		</div>
	<? } else { ?>
		<div class="input">
			<form action="./runner_update.php" action="post">
				<input type="hidden" name="ru_id" value="<?=$ru['ru_id']?>" />
				<input type="hidden" name="ri_id" value="<?=$item['ri_id']?>" />
				<input type="hidden" name="ri_name" value="<?=$item['ri_name']?>" />
				<input type="number" name="ru_value" class="form-input" value="" placeholder="판돈입력" max="<?=$member['mb_point']?>"/>
				<button type="submit" class="ui-btn point">판돈걸기</button>
			</form>
		</div>
	<? } ?>
</div>