<?php
include_once('./_common.php');
$g5['title'] = "경주도박장";
include_once('./_head.php');

add_stylesheet('<link rel="stylesheet" href="'.G5_URL.'/runner/css/style.css">', 0);

// 시작일시의 가장 최근의 경기를 불러온다.
$now = date('Y-m-d H:i:s');
$ru = sql_fetch("select * from {$g5['runner_table']} where ru_sdatetime <= '{$now}' order by ru_sdatetime desc limit 0, 1");

if($ru['ru_id']) { 
	
	// 경기 종료 시간이 지났는데 ru_win 정보가 없을 경우
	$is_game_ing = true;
	if($ru['ru_win']) {
		$is_game_ing = false;

		// 1등에 판돈 건 캐릭터 목록 가져오기
		$ch_name_array = array();
		$batting = sql_query("select * from {$g5['runner_log_table']} where ru_id = '{$ru['ru_id']}' and ri_id = '{$ru['ru_win']}'");
		for($i=0; $ba = sql_fetch_array($batting); $i++) {
			$ch_name_array[] = $ba['ch_name'];
		}
	} else {
		// 날짜 비교
		if($ru['ru_edatetime'] <= $now) {
			// 종료되었다.
			$is_game_ing = false;

			// 게임 종료 처리 하기
			// 각 러너들의 결과를 체크한다.

			$cnt = 0;
			$chk = $order = array();
			while ($cnt < 4) {
				$rand = mt_rand(40,100);
				if (!isset($chk[$rand])) {
					$chk[$rand] = 1;
					$order[$cnt]['grade'] = $rand;
					$order[$cnt]['runner'] = $ru['ri_id_'.($cnt+1)];
					$order[$cnt]['index'] = ($cnt+1);
					$cnt++;
				}
			}
			rsort($order);
			$ru_win = $order[0]['runner'];

			for($i=0; $i < count($order); $i++) {
				$str = "ru_grade_{$order[$i]['index']}";
				if($i == 0) {
					// 1위는 무조건 100%
					$order[$i]['grade'] = 100;
				}
				$$str = ($i+1)."||".$order[$i]['grade'];
			}

			$sql = " update {$g5['runner_table']} set 
				ru_win = '{$ru_win}',
				ru_grade_1 = '{$ru_grade_1}',
				ru_grade_2 = '{$ru_grade_2}',
				ru_grade_3 = '{$ru_grade_3}',
				ru_grade_4 = '{$ru_grade_4}'
				where ru_id = '{$ru['ru_id']}'
			";
			sql_query($sql);

			$ru['ru_win'] = $ru_win;
			$ru['ru_grade_1'] = $ru_grade_1;
			$ru['ru_grade_2'] = $ru_grade_2;
			$ru['ru_grade_3'] = $ru_grade_3;
			$ru['ru_grade_4'] = $ru_grade_4;

			// 배팅 금액 일괄 지급 + 1등에 판돈 건 캐릭터 목록 가져오기
			$ch_name_array = array();
			$batting = sql_query("select * from {$g5['runner_log_table']} where ru_id = '{$ru['ru_id']}' and ri_id = '{$ru_win}'");
			$win_add_per = $ru['ru_win_val'] > 0 ? $ru['ru_win_val'] : 1;
			for($i=0; $ba = sql_fetch_array($batting); $i++) {
				// 배팅 금액 입금
				insert_point($ba['mb_id'], ($ba['ru_value'] * $win_add_per), "{$ru['ru_title']} 경기 : {$ba['ri_name']} 배팅 성공! (".($ba['ru_value'] * $win_add_per).")", 'game', time(), '배팅');
				$ch_name_array[] = $ba['ch_name'];
			}
			$sql = " update {$g5['runner_log_table']} set ru_result = ru_value * {$win_add_per} where ru_id = '{$ru['ru_id']}' and ri_id = '{$ru_win}'";
			sql_query($sql);

			// 경기 참여 애기들 전적 입력
			$sql = " update {$g5['runner_item_table']} set ri_total = ri_total + 1  where ri_id = '{$ru['ri_id_1']}' or ri_id = '{$ru['ri_id_2']}' or ri_id = '{$ru['ri_id_3']}' or ri_id = '{$ru['ri_id_4']}'";
			sql_query($sql);

			// 승리한 애기한테 승점 +1
			$sql = " update {$g5['runner_item_table']} set ri_count = ri_count + 1  where ri_id = '{$ru_win}'";
			sql_query($sql);

		} else {
			$someTime=strtotime("{$ru['ru_edatetime']}") - strtotime($now);
			$hours = floor($someTime/3600);
			$someTime = $someTime - ($hours*3600);
			$min = floor($someTime/60);
			$sec = $someTime - ($min*60);
			
			$someTime = "{$hours}:{$min}:{$sec}";
		}
	}

	$item1 = get_runner($ru['ri_id_1']);
	$item2 = get_runner($ru['ri_id_2']);
	$item3 = get_runner($ru['ri_id_3']);
	$item4 = get_runner($ru['ri_id_4']);

	// 판돈 걸었는지 아닌지 확인
	$my = sql_fetch("select * from {$g5['runner_log_table']} where ru_id = '{$ru['ru_id']}' and ch_id = '{$character['ch_id']}'");
}

?>


<div class="runnerWrap">

<? if($ru['ru_id']) { ?>
	<div class="tit">
		<?=$ru['ru_title']?>
	</div>
	<? if($ru['ru_win_val']) { ?>
		<div class="theme-box txt-center">
			승리시 <?=$ru['ru_win_val']?>배 획득!
		</div>
		<br />
	<? } ?>

	<div class="list theme-box">
		<ul>
			<li>
				<?
					$item = $item1;
					include('./item.skin.php');
				?>
			</li>
			<li>
				<?
					$item = $item2;
					include('./item.skin.php');
				?>
			</li>
			<li>
				<?
					$item = $item3;
					include('./item.skin.php');
				?>
			</li>
			<li>
				<?
					$item = $item4;
					include('./item.skin.php');
				?>
			</li>
		</ul>
	</div>

	<? if($is_game_ing) { ?>
		<div class="counter theme-box">
			경주 시작까지 남은 시간 <span id="timer" class="txt-point"><?=$someTime?></span>
		</div>
		<script>
			startTimer();

			function startTimer() {
				var presentTime = document.getElementById('timer').innerHTML;
				var timeArray = presentTime.split(/[:]+/);
				var h = timeArray[0];
				var m = timeArray[1];
				var s = checkSecond((timeArray[2] - 1));
				if(s==59){m=m-1;  m = checkSecond(m);}
				if(m==59){h=h < 1 ? 0 : h-1}
				if((m + '').length == 1){
					m = '0' + m;
				}
				if(h <= 0 && m <= 0 && s == '00'){
					// 경기 종료 시간 도달!
					// 페이지를 그냥 새로고침 해버린다.
					location.reload();
				} else {
					document.getElementById('timer').innerHTML = h + ":" + m + ":" + s;
					setTimeout(startTimer, 1000);
				}
				
			}

			function checkSecond(sec) {
				if (sec < 10 && sec >= 0) {sec = "0" + sec};
				if (sec < 0) {sec = "59"};
				return sec;
			}
		</script>
	<? } else {
		$data1 = explode("||", $ru['ru_grade_1']);
		$data2 = explode("||", $ru['ru_grade_2']);
		$data3 = explode("||", $ru['ru_grade_3']);
		$data4 = explode("||", $ru['ru_grade_4']);
	?>
		<div class="start-log">
			<p>경주 시작!</p>
		</div>
		<div class="gameResult">
			<dl>
				<dt><?=$item1['ri_name']?></dt>
				<dd>
					<div class="bar">
						<span style="width:<?=$data1[1]?>%; background:<?=$item1['ri_color']?>;"><i><?=$data1[0]?>위<?=$data1[0] == 1 ? "!" : ""?></i></span>
					</div>
				</dd>
			</dl>
			<dl>
				<dt><?=$item2['ri_name']?></dt>
				<dd>
					<div class="bar">
						<span style="width:<?=$data2[1]?>%; background:<?=$item2['ri_color']?>;"><i><?=$data2[0]?>위<?=$data2[0] == 1 ? "!" : ""?></i></span>
					</div>
				</dd>
			</dl>
			<dl>
				<dt><?=$item3['ri_name']?></dt>
				<dd>
					<div class="bar">
						<span style="width:<?=$data3[1]?>%; background:<?=$item3['ri_color']?>;"><i><?=$data3[0]?>위<?=$data3[0] == 1 ? "!" : ""?></i></span>
					</div>
				</dd>
			</dl>
			<dl>
				<dt><?=$item4['ri_name']?></dt>
				<dd>
					<div class="bar">
						<span style="width:<?=$data4[1]?>%; background:<?=$item4['ri_color']?>;"><i><?=$data4[0]?>위<?=$data4[0] == 1 ? "!" : ""?></i></span>
					</div>
				</dd>
			</dl>
		</div>

		<div class="character-list theme-box">
			<ul>
				<? for($i=0; $i < count($ch_name_array); $i++) {?>
				<li>
					<?=$ch_name_array[$i]?>
				</li>
				<? }
					if($i == 0) { 
				?>
				<li class="no-character">
					1등이 없습니다.
				</li>
				<? } ?>
			</ul>
		</div>

	<? } ?>

<? } else { ?>
	<div class="nodata theme-box">
		게임 정보가 없습니다.
	</div>

<? } ?>
</div>



<?php
include_once('./_tail.php');
?>

