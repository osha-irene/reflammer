<?php
$sub_menu = '840100';
include_once('./_common.php');

if ($w == "u" || $w == "d")
	check_demo();

if ($w == 'd')
	auth_check($auth[$sub_menu], "d");
else
	auth_check($auth[$sub_menu], "w");

check_admin_token();


$sql_common = " ru_title		= '{$ru_title}',
				ru_sdatetime	= '{$ru_sdatetime}',
				ru_edatetime	= '{$ru_edatetime}',
				ru_win_val		= '{$ru_win_val}',
				ri_id_1			= '{$ri_id_1}',
				ri_id_2			= '{$ri_id_2}',
				ri_id_3			= '{$ri_id_3}',
				ri_id_4			= '{$ri_id_4}'";

if ($w == "")
{
	$sql = " insert {$g5['runner_table']}
				set $sql_common ";
	sql_query($sql);
}
else if ($w == "u")
{

	$ru = sql_fetch("select * from {$g5['runner_table']} where ru_id = '{$ru_id}'");
	if(!$ru['ru_id']) {
		alert("경기 정보가 존재하지 않습니다.");
	}
	$sql = " update {$g5['runner_table']}
				set $sql_common
			  where ru_id = '$ru_id' ";
	sql_query($sql);

}
else if ($w == "d")
{
	$ru = sql_fetch("select * from {$g5['runner_table']} where ru_id = '{$ru_id}'");
	if(!$ru['ru_id']) {
		alert("경기 정보가 존재하지 않습니다.");
	}
	sql_query(" delete from {$g5['runner_table']} where ru_id = '$ru_id' ");
	sql_query(" delete from {$g5['runner_log_table']} where ru_id = '$ru_id' ");
}

if($ru_id && $w != 'd') { 
	goto_url("./runner_form.php?w=u&ru_id={$ru_id}");
} else { 
	goto_url("./runner_list.php");
}
?>
