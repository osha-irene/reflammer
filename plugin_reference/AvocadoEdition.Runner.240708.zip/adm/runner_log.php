<?php
$sub_menu = "840100";
include_once('./_common.php');

// 레이드 정보 테이블
if($ru_id) { 
	$ru = sql_fetch("select * from {$g5['runner_table']} where ru_id = '{$ru_id}'");
}
if(!$ru['ru_id']) {
	alert("경기 정보가 확인되지 않습니다.");
}


$sql_common = " from {$g5['runner_log_table']} where ru_id = '{$ru_id}' ";

if ($stx) {
	$sql_search .= " and ( ";
	switch ($sfl) {
		default :
			$sql_search .= " ({$sfl} like '%{$stx}%') ";
			break;
	}
	$sql_search .= " ) ";
}


if (!$sst) {
	$sst  = "ru_datetime";
	$sod = "desc";
}
$sql_order = " order by {$sst} {$sod} ";

$sql = " select count(*) as cnt
			{$sql_common}
			{$sql_search}
			{$sql_order} ";
$row = sql_fetch($sql);
$total_count = $row['cnt'];

$rows = 100;
$total_page  = ceil($total_count / $rows);  // 전체 페이지 계산
if ($page < 1) $page = 1; // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record = ($page - 1) * $rows; // 시작 열을 구함

$sql = " select *
			{$sql_common}
			{$sql_search}
			{$sql_order}
			limit {$from_record}, {$rows} ";
$result = sql_query($sql);


$listall = '<a href="'.$_SERVER['SCRIPT_NAME'].'" class="ov_listall">전체목록</a>';

$g5['title'] = $ru['ru_title']." 배팅 로그보기";
include_once('./admin.head.php');


$colspan = 6;
?>


<section id="anc_003">

	<h2 class="h2_frm">전체로그</h2>

	<div class="local_ov01 local_ov">
		<?php echo $listall ?>
		로그 수 <?php echo number_format($total_count) ?>개
	</div>

	<form id="fsearch" name="fsearch" class="local_sch01 local_sch" method="get">
		<label for="sfl" class="sound_only">검색대상</label>
		<input type="hidden" name="ru_id" value="<?=$ru_id?>" />
		<select name="sfl" id="sfl">
			<option value="ch_name"<?php echo get_selected($_GET['sfl'], "ch_name"); ?>>캐릭터 이름</option>
			<option value="ri_name"<?php echo get_selected($_GET['sfl'], "ri_name"); ?>>경주대상이름</option>
		</select>
		<label for="stx" class="sound_only">검색어<strong class="sound_only"> 필수</strong></label>
		<input type="text" name="stx" value="<?php echo $stx ?>" id="stx" class="frm_input">
		<input type="submit" class="btn_submit" value="검색">
	</form>

	<br />

	<div class="tbl_head01 tbl_wrap">
		<table>
		<caption><?php echo $g5['title']; ?> 목록</caption>
		<thead>
		<tr>
			<th style="width:50px;">번호</th>
			<th>캐릭명</th>
			<th style="width:100px;">배팅대상</th>
			<th style="width:100px;">배팅금액</th>
			<th style="width:100px;">배팅결과</th>
			<th style="width:100px;">일시</th>
		</tr>
		</thead>
		<tbody>
		<?php
		for ($i=0; $rl=sql_fetch_array($result); $i++) {
			$bg = 'bg'.($i%2);
		?>

		<tr class="<?php echo $bg; ?>">
			<td><?=$rl['rl_id']?></td>
			<td class="txt-left"><?=$rl['ch_name']?></td>
			<td><?=$rl['ri_name']?></td>
			<td><?=$rl['ru_value']?></td>
			<td><?=$rl['ru_result']?></td>
			<td><?=$rl['ru_datetime']?></td>
		</tr>

		<?php
		}
		if ($i==0)
			echo '<tr><td colspan="'.$colspan.'" class="empty_table">등록된 로그가 없습니다.</td></tr>';
		?>
		</tbody>
		</table>
	</div>

	<div class="btn_list01 btn_list">
		
	</div>


	<?php echo get_paging(G5_IS_MOBILE ? $config['cf_mobile_pages'] : $config['cf_write_pages'], $page, $total_page, "{$_SERVER['SCRIPT_NAME']}?$qstr&amp;ru_id={$ru_id}&amp;page="); ?>

</section>


<?php
include_once('./admin.tail.php');
?>

