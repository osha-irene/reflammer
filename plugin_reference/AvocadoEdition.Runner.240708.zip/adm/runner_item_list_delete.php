<?php
$sub_menu = '840200';
include_once('./_common.php');

check_demo();

if (!count($_POST['chk'])) {
	alert($_POST['act_button']." 하실 항목을 하나 이상 체크하세요.");
}

auth_check($auth[$sub_menu], 'w');

$runner_item_path = G5_DATA_PATH."/runner";
$runner_item_url = G5_DATA_URL."/runner";

@mkdir($runner_item_path, G5_DIR_PERMISSION);
@chmod($runner_item_path, G5_DIR_PERMISSION);


if ($_POST['act_button'] == "선택수정") {
	
	for ($i=0; $i<count($_POST['chk']); $i++)
	{
		$sql_common = "";

		// 실제 번호를 넘김
		$k = $_POST['chk'][$i];
		$ri = sql_fetch("select * from {$g5['runner_item_table']} where ri_id = '{$_POST['ri_id'][$k]}'");
		
		if (!$ri['ri_id']) {
			$msg .= $ri['ri_id'].' : 기존 자료가 존재하지 않습니다.\\n';
		} else {

			if ($img = $_FILES['ri_img_file']['name'][$k]) {
				if (!preg_match("/\.(gif|jpg|png)$/i", $img)) {
					alert("관련 이미지가 gif, jpg, png 파일이 아닙니다.");
				} else {
					// 기존 데이터 삭제
					$prev_file_path = str_replace(G5_URL, G5_PATH, $ri['ri_img'][$k]);
					@unlink($prev_file_path);
					
					// 확장자 따기
					$exp = explode(".", $_FILES['ri_img_file']['name'][$k]);
					$exp = $exp[count($exp)-1];

					$image_name = "runner_item_".time()."_{$i}.".$exp;
					upload_file($_FILES['ri_img_file']['tmp_name'][$k], $image_name, $runner_item_path);
					$image_url = $runner_item_url."/".$image_name;

					$ri_img[$k] = $image_url;
				}
			}

			$sql = " update {$g5['runner_item_table']}
						set ri_name = '{$_POST['ri_name'][$k]}',
							ri_color = '{$_POST['ri_color'][$k]}',
							ri_img = '{$ri_img[$k]}'";
			
			$sql .= "   where ri_id = '{$_POST['ri_id'][$k]}' ";
			sql_query($sql);
		}
	}
} else if ($_POST['act_button'] == "선택삭제") {

	$count = count($_POST['chk']);
	for ($i=0; $i<$count; $i++)
	{
		// 실제 번호를 넘김
		$k = $_POST['chk'][$i];

		// 내역삭제
		$sql = " delete from {$g5['runner_item_table']} where ri_id = '{$_POST['ri_id'][$k]}' ";
		sql_query($sql);

		// 이미지 삭제
		if($_POST['ri_img'][$k]) { 
			// 기존 데이터 삭제
			$prev_file_path = str_replace(G5_URL, G5_PATH, $_POST['ri_img'][$k]);
			@unlink($prev_file_path);
		}
	}
}

if ($msg)
	alert($msg);
goto_url('./runner_item_list.php?'.$qstr);
?>