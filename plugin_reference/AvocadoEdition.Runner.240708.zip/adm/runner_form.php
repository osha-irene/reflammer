<?php
$sub_menu = '840100';
include_once('./_common.php');
add_stylesheet('<link rel="stylesheet" href="'.G5_CSS_URL.'/jquery.datetimepicker.min.css">', 0);
auth_check($auth[$sub_menu], "w");

$html_title = "경주 게임";
$g5['title'] = $html_title.' 관리';

if ($w == "u")
{
	$html_title .= " 수정";
	$readonly = " readonly";

	$sql = " select * from {$g5['runner_table']} where ru_id = '$ru_id' ";
	$ru = sql_fetch($sql);
	if (!$ru['ru_id']) alert('등록된 자료가 없습니다.');

	$html_title = "경주 게임({$ru['ru_title']}";
	$g5['title'] = $html_title.' 수정';
} else {
	$html_title = '경주 게임 등록';
	$g5['title'] = $html_title;
}

// 경주대상목록 가져오기
$runner_item = array();
$runner_item_result = sql_query("select * from {$g5['runner_item_table']} order by ri_name asc");
for($i=0; $row = sql_fetch_array($runner_item_result); $i++) { 
	$runner_item[$i] = $row;
	$runner_item[$i]['win'] = number_format(($row['ri_count'] == 0 ? 0 : (($row['ri_count']/$row['ri_total'])*100)), 3);
}


$frm_submit = '<div class="btn_confirm01 btn_confirm">
	<input type="submit" value="확인" class="btn_submit" accesskey="s">
	<a href="./runner_list.php?{$qstr}">목록</a>
</div>';

include_once (G5_ADMIN_PATH.'/admin.head.php');
?>

<form name="frmrunner_form" action="./runner_form_update.php" onsubmit="return frmrunner_form_check(this);" method="post" >
<input type="hidden" name="w" value="<?php echo $w; ?>">
<input type="hidden" name="ru_id" value="<?php echo $ru_id; ?>">
<input type="hidden" name="token" value="">

<section id="anc_001">

	<div class="tbl_frm01 tbl_wrap">
		<table>
		<caption><?php echo $g5['title']; ?> 목록</caption>
		<colgroup>
			<col style="width: 120px;">
			<col style="width: 100px;">
			<col>
		</colgroup>
		<tbody>
		<tr>
			<th scope="row">경기명</th>
			<td colspan="2">
				<input type="text" name="ru_title" value="<?php echo $ru['ru_title']; ?>" class="frm_input" />
			</td>
		</tr>
		<tr>
			<th scope="row">승자획득배율</th>
			<td colspan="2">
				<?php echo help('※ 배팅에 성공한 멤버가 획득할 배율을 설정합니다.') ?>
				<?php echo help('※ 1등을 고르는데 성공할 경우, 배팅한 금액 x 배율 만큼 포인트를 다시 획득하게 됩니다.') ?>
				<input type="text" name="ru_win_val" value="<?php echo $ru['ru_win_val']; ?>" class="frm_input" style="width:100px;"/> 배
			</td>
		</tr>
		<tr>
			<th scope="row" rowspan="2">경기운영시간</th>
			<td class="bo-right">
				경기오픈일시
			</td>
			<td>
				<? if($ru['ru_win']) { ?>
					<input type="hidden" name="ru_sdatetime" class="datetimepicker" value="<?php echo $ru['ru_sdatetime']; ?>">
					<?=$ru['ru_sdatetime']?>
				<? } else { ?>
					<?php echo help('※ 24시간 표기법을 사용합니다.') ?>
					<?php echo help('※ 경기오픈일시가 되면 배팅을 시작할 수 있습니다.') ?>
					<input type="text" name="ru_sdatetime" value="<?php echo $ru['ru_sdatetime']; ?>" class="datetimepicker frm_input" size="20" placeholder="0000-00-00 00:00:00">
				<? } ?>
			</td></tr><tr>
			<td class="bo-right">
				경기시작시간
			</td>
			<td>
				<? if($ru['ru_win']) { ?>
					<input type="hidden" name="ru_edatetime" class="datetimepicker" value="<?php echo $ru['ru_edatetime']; ?>">
					<?=$ru['ru_edatetime']?>
				<? } else { ?>
					<?php echo help('※ 24시간 표기법을 사용합니다.') ?>
					<?php echo help('※ 경기시작시간이 되면 경기 결과가 결정됩니다.') ?>
					<input type="text" name="ru_edatetime" value="<?php echo $ru['ru_edatetime']; ?>" class="datetimepicker  frm_input" size="20" placeholder="0000-00-00 00:00:00">
				<? } ?>
			</td>
		</tr>
		
		<tr>
			<th scope="row" rowspan="4">참가경주대상</th>
			<td class="bo-right">
				1번라인
			</td>
			<td>
				<? if($ru['ru_win']) { ?>
					<input type="hidden" name="ri_id_1" value="<?php echo $ru['ri_id_1']; ?>" />
					<?=get_runner_name($ru['ri_id_1'])?>
					<?
						$data = explode("||", $ru['ru_grade_1']);
					?>
					: <strong><?=$data[0]?>위</strong> (<?=$data[1]?>)
				<? } else { ?>
					<select name="ri_id_1">
						<option value="">대상선택</option>
						<? for($k=0; $k < count($runner_item); $k++) { ?>
							<option value="<?=$runner_item[$k]['ri_id']?>" <?php echo get_selected($ru['ri_id_1'], $runner_item[$k]['ri_id']); ?>>
								- <?=$runner_item[$k]['ri_name']?> (승 : <?=$runner_item[$k]['ri_count']?>/<?=$runner_item[$k]['ri_total']?>)
							</option>
						<? } ?>
					</select>
				<? } ?>
			</td></tr><tr>
			<td class="bo-right">
				2번라인
			</td>
			<td>
				<? if($ru['ru_win']) { ?>
					<input type="hidden" name="ri_id_2" value="<?php echo $ru['ri_id_2']; ?>" />
					<?=get_runner_name($ru['ri_id_2'])?>
					<?
						$data = explode("||", $ru['ru_grade_2']);
					?>
					 : <strong><?=$data[0]?>위</strong> (<?=$data[1]?>)
				<? } else { ?>
					<select name="ri_id_2">
						<option value="">대상선택</option>
						<? for($k=0; $k < count($runner_item); $k++) { ?>
							<option value="<?=$runner_item[$k]['ri_id']?>" <?php echo get_selected($ru['ri_id_2'], $runner_item[$k]['ri_id']); ?>>
								- <?=$runner_item[$k]['ri_name']?> (승 : <?=$runner_item[$k]['ri_count']?>/<?=$runner_item[$k]['ri_total']?>)
							</option>
						<? } ?>
					</select>
				<? } ?>
			</td></tr><tr>
			<td class="bo-right">
				3번라인
			</td>
			<td>
				<? if($ru['ru_win']) { ?>
					<input type="hidden" name="ri_id_3" value="<?php echo $ru['ri_id_3']; ?>" />
					<?=get_runner_name($ru['ri_id_3'])?>
					<?
						$data = explode("||", $ru['ru_grade_3']);
					?>
					: <strong><?=$data[0]?>위</strong> (<?=$data[1]?>)
				<? } else { ?>
					<select name="ri_id_3">
						<option value="">대상선택</option>
						<? for($k=0; $k < count($runner_item); $k++) { ?>
							<option value="<?=$runner_item[$k]['ri_id']?>" <?php echo get_selected($ru['ri_id_3'], $runner_item[$k]['ri_id']); ?>>
								- <?=$runner_item[$k]['ri_name']?> (승 : <?=$runner_item[$k]['ri_count']?>/<?=$runner_item[$k]['ri_total']?>)
							</option>
						<? } ?>
					</select>
				<? } ?>
			</td></tr><tr>
			<td class="bo-right">
				4번라인
			</td>
			<td>
				<? if($ru['ru_win']) { ?>
					<input type="hidden" name="ri_id_4" value="<?php echo $ru['ri_id_4']; ?>" />
					<?=get_runner_name($ru['ri_id_4'])?>
					<?
						$data = explode("||", $ru['ru_grade_4']);
					?>
					: <strong><?=$data[0]?>위</strong> (<?=$data[1]?>)
				<? } else { ?>
					<select name="ri_id_4">
						<option value="">대상선택</option>
						<? for($k=0; $k < count($runner_item); $k++) { ?>
							<option value="<?=$runner_item[$k]['ri_id']?>" <?php echo get_selected($ru['ri_id_4'], $runner_item[$k]['ri_id']); ?>>
								- <?=$runner_item[$k]['ri_name']?> (승 : <?=$runner_item[$k]['ri_count']?>/<?=$runner_item[$k]['ri_total']?>)
							</option>
						<? } ?>
					</select>
				<? } ?>
			</td>
		</tr>
		</tbody>
		</table>
	</div>
</section>
<? echo $frm_submit; ?>

</form>

<script src="<?=G5_JS_URL?>/jquery.datetimepicker.full.min.js"></script>
<script>
$('.datetimepicker').datetimepicker({format:'Y-m-d H:i:s',lang:'kr',step: 5});
function frmrunner_form_check(f) {
	return true;
}
</script>

<?php
include_once (G5_ADMIN_PATH.'/admin.tail.php');
?>
