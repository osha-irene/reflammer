<?php
$sub_menu = "840100";
include_once('./_common.php');

check_demo();

if (!count($_POST['chk'])) {
	alert($_POST['act_button']." 하실 항목을 하나 이상 체크하세요.");
}

if ($_POST['act_button'] == "선택수정") {

	auth_check($auth[$sub_menu], 'w');

	for ($i=0; $i<count($_POST['chk']); $i++) {

		// 실제 번호를 넘김
		$k = $_POST['chk'][$i];

		$sql = " update {$g5['runner_table']}
					set ru_title			= '{$_POST['ru_title'][$k]}',
						ru_sdatetime		= '{$_POST['ru_sdatetime'][$k]}',
						ru_edatetime		= '{$_POST['ru_edatetime'][$k]}',
						ru_win_val			= '{$_POST['ru_win_val'][$k]}'
				  where ru_id				= '{$_POST['ru_id'][$k]}' ";
		sql_query($sql);
	}

} else if ($_POST['act_button'] == "선택삭제") {
	auth_check($auth[$sub_menu], 'd');
	check_token();

	for ($i=0; $i<count($_POST['chk']); $i++) {
		$k = $_POST['chk'][$i];
		$temp_ru_id = trim($_POST['ru_id'][$k]);
		if (!$temp_ru_id) { return; }

		$ru = sql_fetch("select * from {$g5['runner_table']} where ru_id = '{$temp_ru_id}'");
		
		sql_query(" delete from {$g5['runner_table']} where ru_id = '$temp_ru_id' ");
		sql_query(" delete from {$g5['runner_log_table']} where ru_id = '$temp_ru_id' ");
	}
}

goto_url('./runner_list.php');
?>
