<?php
$menu['menu840'] = array (
	array('840000', '경주 관리', ''.G5_ADMIN_URL.'/runner_list.php', ''),
	array('840100', '경주일정', ''.G5_ADMIN_URL.'/runner_list.php', ''),
	array('840200', '경주대상 관리', ''.G5_ADMIN_URL.'/runner_item_list.php', '')
);
?>