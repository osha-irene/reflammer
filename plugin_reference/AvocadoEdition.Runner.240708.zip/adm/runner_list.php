<?php
$sub_menu = "840100";
include_once('./_common.php');
add_stylesheet('<link rel="stylesheet" href="'.G5_CSS_URL.'/jquery.datetimepicker.min.css">', 0);

auth_check($auth[$sub_menu], 'r');

$sql_common = " from {$g5['runner_table']} ";
$sql_search = " where (1) ";
$sql_order = " order by ru_sdatetime desc, ru_id desc ";

$sql = " select count(*) as cnt {$sql_common} {$sql_search} {$sql_order} ";
$row = sql_fetch($sql);
$total_count = $row['cnt'];

$rows = $config['cf_page_rows'];
$total_page  = ceil($total_count / $rows);  // 전체 페이지 계산
if ($page < 1) { $page = 1; } // 페이지가 없으면 첫 페이지 (1 페이지)
$from_record = ($page - 1) * $rows; // 시작 열을 구함

$sql = " select * {$sql_common} {$sql_search} {$sql_order} limit {$from_record}, {$rows} ";
$result = sql_query($sql);

$listall = '<a href="'.$_SERVER['PHP_SELF'].'" class="ov_listall">전체목록</a>';

$g5['title'] = '경주 게임';
include_once('./admin.head.php');

$colspan = 16;

?>


<section id="anc_001" style="margin-top: 0; min-width:1200px;">
	<h2 class="h2_frm">경주 일정</h2>
	<?php echo $pg_anchor ?>

	<div class="local_ov01 local_ov">
		<?php echo $listall ?>
		추가된 게임 수 <?php echo number_format($total_count) ?>개
	</div>

	<?php if ($is_admin == 'super') { ?>
	<div class="btn_add01 btn_add">
		<a href="./runner_form.php" id="bo_add">게임 추가</a>
		<a href="<?=G5_URL?>/runner/" target="_blank">경기장 바로가기</a>
	</div>
	<?php } ?>

	<form name="fitemlist" id="fitemlist" action="./runner_list_update.php" onsubmit="return fitemlist_submit(this);" method="post">
	<input type="hidden" name="sst" value="<?php echo $sst ?>">
	<input type="hidden" name="sod" value="<?php echo $sod ?>">
	<input type="hidden" name="sfl" value="<?php echo $sfl ?>">

	<input type="hidden" name="stx" value="<?php echo $stx ?>">
	<input type="hidden" name="page" value="<?php echo $page ?>">
	<input type="hidden" name="token" value="<?php echo $token ?>">

	<div class="tbl_head01 tbl_wrap">
		<table>
			<caption><?php echo $g5['title']; ?> 목록</caption>
			<colgroup>
				<col style="width:  50px;" />
				<col />
				<col style="width: 170px;" />
				<col style="width: 170px;" />

				<col style="width: 110px;" />

				<col style="width: 50px;" />
				<col style="width: 100px;" />
				<col style="width: 50px;" />
				<col style="width: 100px;" />
				<col style="width: 50px;" />
				<col style="width: 100px;" />
				<col style="width: 50px;" />
				<col style="width: 100px;" />
				<col style="width: 50px;" />
				<col style="width: 100px;" />

				<col style="width: 80px;" />
				<col style="width: 80px;" />
			</colgroup>
			<thead>
				<tr>
					<th scope="col" rowspan="2" class="bo-right">
						<input type="checkbox" name="chkall" value="1" id="chkall" onclick="check_all(this.form)">
					</th>
					
					<th scope="col" class="bo-left">경기명</th>
					<th scope="col" class="bo-left">오픈일시</th>
					<th scope="col" class="bo-left">경기일시</th>
					<th scope="col" class="bo-left">승리획득</th>
					<th scope="col" class="bo-left" colspan="2">1번</th>
					<th scope="col" class="bo-left" colspan="2">2번</th>
					<th scope="col" class="bo-left" colspan="2">3번</th>
					<th scope="col" class="bo-left" colspan="2">4번</th>
					<th scope="col" class="bo-left" colspan="2">승리</th>
					<th scope="col" class="bo-left">로그</th>
					<th scope="col" class="bo-left">수정</th>
				</tr>
			</thead>
			<tbody>
				<?php
				for ($i=0; $ru=sql_fetch_array($result); $i++) {
					$one_update = '<a href="./runner_form.php?w=u&amp;ru_id='.$ru['ru_id'].'&amp;'.$qstr.'">수정</a>';
					$bg = 'bg'.($i%2);

					$item_01 = get_runner_img($ru['ri_id_1']);
					$item_02 = get_runner_img($ru['ri_id_2']);
					$item_03 = get_runner_img($ru['ri_id_3']);
					$item_04 = get_runner_img($ru['ri_id_4']);
					$item_win = get_runner_img($ru['ru_win']);
				?>

				<tr class="<?php echo $bg; ?>">
					<td>
						<input type="checkbox" name="chk[]" value="<?php echo $i ?>" id="chk_<?php echo $i ?>">
						<input type="hidden" name="ru_id[<?php echo $i ?>]" value="<?php echo $ru['ru_id'] ?>" />
					</td>
					
					<td>
						<input type="text" name="ru_title[<?php echo $i ?>]" value="<?php echo get_text($ru['ru_title']) ?>" class="full_input">
					</td>
					<td>
						<input type="text" name="ru_sdatetime[<?php echo $i ?>]" class="datetimepicker full_input" style="width:100%;" value="<?php echo get_text($ru['ru_sdatetime']) ?>" />
					</td>
					<td>
						<input type="text" name="ru_edatetime[<?php echo $i ?>]" class="datetimepicker full_input" style="width:100%;" value="<?php echo get_text($ru['ru_edatetime']) ?>" />
					</td>
					<td>
						<input type="text" name="ru_win_val[<?php echo $i ?>]" class="full_input" style="width:70%;" value="<?php echo get_text($ru['ru_win_val']) ?>" />배
					</td>

					<td><? if($item_01) { ?><img src="<?=$item_01?>" style="width:20px; height:20px; object-fit:container;" /><? } ?></td>
					<td>
						<?=get_runner_name($ru['ri_id_1'])?>
					</td>
					<td><? if($item_02) { ?><img src="<?=$item_02?>" style="width:20px; height:20px; object-fit:container;" /><? } ?></td>
					<td>
						<?=get_runner_name($ru['ri_id_2'])?>
					</td>
					<td><? if($item_03) { ?><img src="<?=$item_03?>" style="width:20px; height:20px; object-fit:container;" /><? } ?></td>
					<td>
						<?=get_runner_name($ru['ri_id_3'])?>
					</td>
					<td><? if($item_04) { ?><img src="<?=$item_04?>" style="width:20px; height:20px; object-fit:container;" /><? } ?></td>
					<td>
						<?=get_runner_name($ru['ri_id_4'])?>
					</td>
					<td><? if($item_win) { ?><img src="<?=$item_win?>" style="width:20px; height:20px; object-fit:container;" /><? } ?></td>
					<td>
						<?=get_runner_name($ru['ru_win'])?>
					</td>

					<td>
						<a href="./runner_log.php?ru_id=<?=$ru['ru_id']?>">보기</a>
					</td>

					<td>
						<?php echo $one_update ?>
					</td>
				</tr>

				<?php
				}
				if ($i == 0)
					echo '<tr><td colspan="'.$colspan.'" class="empty_table">자료가 없습니다.</td></tr>';
				?>
			</tbody>
		</table>
	</div>

	<div class="btn_list01 btn_list">
		<input type="submit" name="act_button" value="선택수정" onclick="document.pressed=this.value">
		<?php if ($is_admin == 'super') { ?>
		<input type="submit" name="act_button" value="선택삭제" onclick="document.pressed=this.value">
		<?php } ?>
	</div>

	</form>

	<?php echo get_paging(G5_IS_MOBILE ? $config['cf_mobile_pages'] : $config['cf_write_pages'], $page, $total_page, $_SERVER['PHP_SELF'].'?'.$qstr.'&amp;cate='.$cate.'&amp;cate2='.$cate2.'&amp;map_id='.$map_id.'&amp;page='); ?>

<script src="<?=G5_JS_URL?>/jquery.datetimepicker.full.min.js"></script>
<script>
	$('.datetimepicker').datetimepicker({format:'Y-m-d H:i:s', lang:'kr',step: 5});

	function fitemlist_submit(f)
	{
		if (!is_checked("chk[]")) {
			alert(document.pressed+" 하실 항목을 하나 이상 선택하세요.");
			return false;
		}

		if(document.pressed == "선택삭제") {
			if(!confirm("선택한 자료를 정말 삭제하시겠습니까?")) {
				return false;
			}
		}

		return true;
	}
	</script>
</section>

<?php
include_once('./admin.tail.php');
?>
