<?php
$sub_menu = "840200";
include_once('./_common.php');

auth_check($auth[$sub_menu], 'w');
check_token();

$runner_item_path = G5_DATA_PATH."/runner";
$runner_item_url = G5_DATA_URL."/runner";

@mkdir($runner_item_path, G5_DIR_PERMISSION);
@chmod($runner_item_path, G5_DIR_PERMISSION);


/** 경주대상 아이콘 등록 **/
$sql_common = "";
if ($img = $_FILES['ri_img_file']['name']) {
	
	if (!preg_match("/\.(gif|jpg|png)$/i", $img)) {
		alert("타이틀 이미지가 gif, jpg, png 파일이 아닙니다.");
	} else {
		// 확장자 따기
		$exp = explode(".", $_FILES['ri_img_file']['name']);
		$exp = $exp[count($exp)-1];

		$image_name = "runner_item_".time().".".$exp;
		upload_file($_FILES['ri_img_file']['tmp_name'], $image_name, $runner_item_path);
		$image_url = $runner_item_url."/".$image_name;

		$ri_img = $image_url;
	}
}

$sql = " insert into {$g5['runner_item_table']}
			set ri_name = '{$_POST['ri_name']}',
				ri_color = '{$_POST['ri_color']}',
				ri_img = '{$ri_img}'";

sql_query($sql);


goto_url('./runner_item_list.php?'.$qstr);
?>
