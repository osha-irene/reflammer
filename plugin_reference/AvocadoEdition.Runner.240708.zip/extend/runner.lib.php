<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

$g5['runner_item_table'] = G5_TABLE_PREFIX.'runner_item'; // 경마 테이블
$g5['runner_table'] = G5_TABLE_PREFIX.'runner'; // 경기 테이블
$g5['runner_log_table'] = G5_TABLE_PREFIX.'runner_log'; // 경마 로그 내역 테이블

if(!sql_query(" DESC {$g5['runner_item_table']} ")) {
	sql_query(" CREATE TABLE IF NOT EXISTS `{$g5['runner_item_table']}` (
		  `ri_id` int(11) NOT NULL AUTO_INCREMENT,
		  `ri_name` varchar(255) NOT NULL default '',
		  `ri_img` varchar(255) NOT NULL default '',
		  `ri_color` varchar(255) NOT NULL default '',
		  `ri_count` int(11) NOT NULL default '0',
		  `ri_total` int(11) NOT NULL default '0',
		  PRIMARY KEY (`ri_id`)
	) ", false);
}

if(!sql_query(" DESC {$g5['runner_table']} ")) {
	sql_query(" CREATE TABLE IF NOT EXISTS `{$g5['runner_table']}` (
		  `ru_id` int(11) NOT NULL AUTO_INCREMENT,
		  `ru_title` varchar(255) NOT NULL default '',
		  `ru_sdatetime` varchar(255) NOT NULL default '',
		  `ru_edatetime` varchar(255) NOT NULL default '',
		  `ri_id_1` int(11) NOT NULL default '0',
		  `ri_id_2` int(11) NOT NULL default '0',
		  `ri_id_3` int(11) NOT NULL default '0',
		  `ri_id_4` int(11) NOT NULL default '0',
		  `ru_win` int(11) NOT NULL default '0',
		  `ru_win_val` int(11) NOT NULL default '0',
		  `ru_grade_1` varchar(255) NOT NULL default '',
		  `ru_grade_2` varchar(255) NOT NULL default '',
		  `ru_grade_3` varchar(255) NOT NULL default '',
		  `ru_grade_4` varchar(255) NOT NULL default '',
		  PRIMARY KEY (`ru_id`)
	) ", false);
}

if(!sql_query(" DESC {$g5['runner_log_table']} ")) {
	sql_query(" CREATE TABLE IF NOT EXISTS `{$g5['runner_log_table']}` (
		  `rl_id` int(11) NOT NULL AUTO_INCREMENT,
		  `ru_id` int(11) NOT NULL default '0',
		  `ri_id` int(11) NOT NULL default '0',
		  `ri_name` varchar(255) NOT NULL default '',
		  `ch_id` int(11) NOT NULL default '0',
		  `mb_id` varchar(255) NOT NULL default '',
		  `ch_name` varchar(255) NOT NULL default '',
		  `ru_value` int(11) NOT NULL default '0',
		  `ru_result` int(11) NOT NULL default '0',
		  `ru_datetime` varchar(255) NOT NULL default '',
		  `ru_state` char(4) NOT NULL default '',
		  PRIMARY KEY (`rl_id`)
	) ", false);
}


function get_runner($ri_id) {
	global $g5;

	$result = sql_fetch("select * from {$g5['runner_item_table']} where ri_id= '{$ri_id}'");
	// 승률
	$result['win'] = number_format(($result['ri_count'] == 0 ? 0 : (($result['ri_count']/$result['ri_total'])*100)), 3);
	return $result;
}
function get_runner_name($ri_id) {
	global $g5;

	$result = sql_fetch("select ri_name from {$g5['runner_item_table']} where ri_id= '{$ri_id}'");
	return $result['ri_name'];
}
function get_runner_img($ri_id) {
	global $g5;

	$result = sql_fetch("select ri_img from {$g5['runner_item_table']} where ri_id= '{$ri_id}'");
	return $result['ri_img'];
}

?>